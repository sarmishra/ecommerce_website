

<html>

	<head>
 		
 		<title>Payment Cancel!</title>

 	</head>

 	<body>

 		<h2>Payment was Cancelled!</h2>
 		<h3>Your Payment Was Not Successful, go back to our shop and try again. </h3>
 		<h3><a href="http://www.homeappliances.com/myshop">Go to Back</a></h3>



 	</body>

</html> 	
