<?php

if(!isset($_SESSION['user_email'])){

echo "<script> window.open('login.php?not_admin=You are not an Admin!','_self')</script>";

}

else{

?>


<table width="795" align="center" bgcolor="pink">


<tr align="center" bgcolor="#3faba4">

	<td colspan="6"><h2>View All Brands Here</h2></td>

</tr>

<tr align="center" bgcolor="#3faba4">

<th>Brand ID</th>
<th>Brand Title</th>
<th>Edit</th>
<th>Delete </th>

</tr>


<?php

include("includes/db.php");

$get_order= "select * from orders"; 

$run_order=mysqli_query($con,$get_order);

$i=0;

while($row_order=mysqli_fetch_array($run_order)){  

	$order_id=$row_order['p_id'];

	$run= "select * from products where $order_id=product_id" ;

	$order=mysqli_query($con,$run);

	while($ro_order=mysqli_fetch_array($order)){

	$order_title=$ro_order['product_title'];

}
	
	$i++;


?>


<tr align="center">

<td> <?php echo $i; ?> </td>
<td> <?php echo $order_title; ?> </td>

<td><a href="index.php?edit_brand=<?php echo $brand_id; ?>">Edit</a></td>
<td><a href="delete_brand.php?delete_brand=<?php echo $brand_id; ?>">Delete</a></td>

</tr>

 <?php } ?>
 

</table>

<?php } ?>











